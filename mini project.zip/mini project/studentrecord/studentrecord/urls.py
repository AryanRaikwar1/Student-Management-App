from django.contrib import admin
from django.urls import path
from studentapp.views import home,login,logout,index,marks

urlpatterns = [ 
    path('',home),
    path('login/',login),
    path('logout/',logout),
    path('admin/', admin.site.urls),
    path('index/',index),
    path('marks/',marks),
]
