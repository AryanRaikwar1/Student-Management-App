from django.http import HttpResponse
from django.shortcuts import render 

def home(request):
    return HttpResponse("Hello World")

def login(request):
    return HttpResponse("Welcome, Glad To See You! ")

def logout(request):
    return HttpResponse("Thanks For Visiting")

from .models import Studentdata
def index(request):
    if request.method =="POST":
        name = request.POST.get('First Name')
        Email = request.POST.get('Email')
        Address = request.POST.get('Address')
        temp = Studentdata(Name=name,Email=Email,Address=Address)
        temp.save()
    return render(request,"index.html") 

from .models import Studentmarks
def marks(request):
    if request.method =="POST":
        sub1 = request.POST.get('sub1')
        sub2 = request.POST.get('sub2')
        sub3 = request.POST.get('sub3')
        sub4 = request.POST.get('sub4')
        sub5 = request.POST.get('sub5')
        temp = Studentmarks(sub1=sub1,sub2=sub2,sub3=sub3,sub4=sub4,sub5=sub5)
        temp.save()
    return render(request,"marks.html")