from django.contrib import admin

from .models import Studentdata,Studentmarks
 
admin.site.register(Studentdata)

admin.site.register(Studentmarks)