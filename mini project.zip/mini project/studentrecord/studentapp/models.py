from django.db import models

# Create your models here.

class Studentdata(models.Model):
    Name = models.CharField(max_length=50)
    Email = models.EmailField()
    Address = models.TextField()

class Studentmarks(models.Model):
    sub1 = models.IntegerField()
    sub2 = models.IntegerField()
    sub3 = models.IntegerField()
    sub4 = models.IntegerField()
    sub5 = models.IntegerField()